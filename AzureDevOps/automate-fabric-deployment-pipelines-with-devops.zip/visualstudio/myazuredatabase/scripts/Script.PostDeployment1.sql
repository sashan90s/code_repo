﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
IF NOT EXISTS (SELECT [name] FROM sys.database_principals WHERE [name] = 'db_executor' and Type = 'R')
BEGIN 
    CREATE ROLE [db_executor]
END
GO
GRANT EXECUTE TO [db_executor]
GO

--Simple logic to populate my Dim.Dates table if empty (database just created) 
IF (SELECT COUNT(1) FROM [dim].[Dates]) = 0 
BEGIN 
    EXEC [sprc].[PopulateDates]
END
