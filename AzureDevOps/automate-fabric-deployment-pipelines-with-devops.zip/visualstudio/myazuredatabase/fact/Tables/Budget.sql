﻿CREATE TABLE [fact].[Budget] (
    [SurrogateKey]        NVARCHAR (60)   NOT NULL,
    [AccountBudgetYYYYMM] NVARCHAR (60)   NOT NULL,
    [BudgetYYYYMM]        INT             NOT NULL,
    [AccountId]           NVARCHAR (50)   NOT NULL,
    [SubcategoryId]       TINYINT         NOT NULL,
    [Amount]              DECIMAL (16, 2) CONSTRAINT [DF_fact.Budget_01] DEFAULT ((0)) NOT NULL,
    [UpsertDtTm]          DATETIME        CONSTRAINT [DF_Budget_InDtTm] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_Budget] PRIMARY KEY CLUSTERED ([SurrogateKey] ASC),
    CONSTRAINT [FK_Budget_ExpensesSubcat] FOREIGN KEY ([SubcategoryId]) REFERENCES [dim].[ExpensesSubcat] ([Id])
);

