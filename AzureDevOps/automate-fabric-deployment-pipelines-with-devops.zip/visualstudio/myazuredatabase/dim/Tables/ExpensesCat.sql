﻿CREATE TABLE [dim].[ExpensesCat] (
    [Id]            TINYINT        IDENTITY (1, 1) NOT NULL,
    [Description]   NVARCHAR (100) NOT NULL,
    [ExpenseTypeId] TINYINT        NOT NULL,
    CONSTRAINT [PK_ExpensesCat] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ExpensesCat_TransactionType] FOREIGN KEY ([ExpenseTypeId]) REFERENCES [dim].[TransactionType] ([Id])
);

