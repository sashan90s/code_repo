﻿CREATE TABLE [dim].[TransactionType] (
    [Id]          TINYINT       NOT NULL,
    [Description] NVARCHAR (50) NOT NULL,
    CONSTRAINT [PK_Transaction_type] PRIMARY KEY CLUSTERED ([Id] ASC)
);

