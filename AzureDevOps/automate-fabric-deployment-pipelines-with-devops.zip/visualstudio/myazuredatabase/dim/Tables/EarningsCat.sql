﻿CREATE TABLE [dim].[EarningsCat] (
    [Id]            TINYINT        IDENTITY (1, 1) NOT NULL,
    [Description]   NVARCHAR (100) NOT NULL,
    [EarningTypeId] TINYINT        NOT NULL,
    CONSTRAINT [PK_EarningsCat] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_EarningsCat_TransactionType] FOREIGN KEY ([EarningTypeId]) REFERENCES [dim].[TransactionType] ([Id])
);

