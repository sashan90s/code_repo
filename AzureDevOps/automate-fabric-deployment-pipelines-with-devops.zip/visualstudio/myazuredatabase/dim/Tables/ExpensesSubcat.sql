﻿CREATE TABLE [dim].[ExpensesSubcat] (
    [Id]          TINYINT        IDENTITY (1, 1) NOT NULL,
    [Description] NVARCHAR (100) NOT NULL,
    [CategoryId]  TINYINT        NOT NULL,
    [Retailers]   NVARCHAR (MAX) DEFAULT ('') NOT NULL,
    [UpsertDtTm]  DATETIME       CONSTRAINT [DF_ExpensesSubcat_UpsertDtTm] DEFAULT (getdate()) NULL,
    CONSTRAINT [PK_ExpensesSubcat] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ExpensesSubcat_ExpensesCat] FOREIGN KEY ([CategoryId]) REFERENCES [dim].[ExpensesCat] ([Id])
);

