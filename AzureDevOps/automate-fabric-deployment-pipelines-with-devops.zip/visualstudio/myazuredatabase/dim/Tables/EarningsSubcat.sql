﻿CREATE TABLE [dim].[EarningsSubcat] (
    [Id]          TINYINT        IDENTITY (1, 1) NOT NULL,
    [Description] NVARCHAR (100) NOT NULL,
    [CategoryId]  TINYINT        NOT NULL,
    [Customers]   NVARCHAR (MAX) NOT NULL,
    [UpsertDtTm]  DATETIME       CONSTRAINT [DF_EarningsSubcat_UpsertDtTm] DEFAULT (getdate()) NULL,
    CONSTRAINT [PK_EarningsSubcat] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_EarningsSubcat_EarningsCat] FOREIGN KEY ([CategoryId]) REFERENCES [dim].[EarningsCat] ([Id])
);

