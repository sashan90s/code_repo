﻿









-- =============================================
-- Author:      Name
-- Create Date: 
-- Description: 
-- =============================================
CREATE PROCEDURE [sprc].[CategorizeExpenses]
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON

/****** Script for SelectTopNRows command from SSMS  ******/

	UPDATE [stg].[Withdrawals] SET [RT]=1 WHERE [Description] LIKE '%Reservert transaksjon%'

	DECLARE @SurrogateKey INT,@Date DATE,@Withdrawals DECIMAL(16,2),@AccountId NVARCHAR(50)
	DECLARE ReservedTransactions CURSOR FOR 
		SELECT
			[SurrogateKey],[Date],[Withdrawals],[AccountId]
		FROM 
			[fact].[Withdrawals]
		WHERE 
			[RT]=1  
	OPEN ReservedTransactions
	FETCH NEXT FROM ReservedTransactions INTO @SurrogateKey,@Date,@Withdrawals,@AccountId
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		UPDATE A SET A.[WithdrawalId] = @SurrogateKey
		FROM [stg].[Withdrawals] A
		INNER JOIN (
			SELECT
				[SurrogateKey]
				,ROW_NUMBER() OVER (PARTITION BY [Date],[Withdrawals],[AccountId] ORDER BY [SurrogateKey]) as Dedup
			FROM 
				[stg].[Withdrawals]
			WHERE 1 = 1 
				AND [Date]=@Date 
				AND [Withdrawals]=@Withdrawals
				AND [AccountId]=@AccountId
				AND [WithdrawalId] IS NULL 
				AND ISNULL([RT],0)=0
		) B on A.[SurrogateKey]=B.[SurrogateKey] and B.[Dedup] = 1 
		FETCH NEXT FROM ReservedTransactions INTO @SurrogateKey,@Date,@Withdrawals,@AccountId
	END 
	CLOSE ReservedTransactions;  
	DEALLOCATE ReservedTransactions;   

	UPDATE A SET 
		A.[Description] = B.[Description], A.[Interest_date] = B.[Interest_date], A.[RT] = B.[RT]
	FROM 
		[fact].[Withdrawals] A 
	INNER JOIN 
		[stg].[Withdrawals] B ON A.[SurrogateKey] = B.[WithdrawalId]

	INSERT INTO [fact].[Withdrawals]
		([Date], [Description], [Interest_date], [Withdrawals], [SubcategoryId], [UpsertDtTm], [Tag], [InputFileName], [AccountId], [RT])
	SELECT 
		[Date], [Description], [Interest_date], [Withdrawals], [SubcategoryId], [UpsertDtTm], [Tag], [InputFileName], [AccountId], [RT]
	FROM 
		[stg].[Withdrawals] A
	WHERE 1 = 1
		AND A.[WithdrawalId] IS NULL 

	TRUNCATE TABLE [stg].[Withdrawals]; 

	;WITH cte AS (
		SELECT 
			ISNULL(esc.[Id],0) as NewSubcategoryId,
			--esc.[Description] as NewSubcategoryDesc,
			--esc.[Retailer],
			ROW_NUMBER() OVER (PARTITION BY w.[SurrogateKey] ORDER BY esc.[Id]) as Dedup,
			w.[SurrogateKey],
			w.[SubcategoryId] as CurrentSubcategoryId
		FROM 
			[fact].[Withdrawals] AS w 
		LEFT JOIN 
			(
				SELECT 
					[Id],[Description],TRIM(value) [Retailer]
				FROM 
					[dim].[ExpensesSubcat]
				CROSS APPLY 
					STRING_SPLIT (Retailers,';') 
			) AS esc ON CHARINDEX([Retailer], w.[Description]) > 0
		WHERE 1 = 1 
			AND IsNull(w.Locked,0)=0
	)

	--SELECT w.*
	UPDATE 
		w 
	SET 
		w.[SubcategoryId] = cte.[NewSubcategoryId],
		w.[Locked] = 0
	FROM 
		[fact].[Withdrawals] w 
		INNER JOIN cte ON w.SurrogateKey = cte.SurrogateKey
	WHERE 1 = 1 
		AND Dedup = 1 
		AND (
			(cte.NewSubcategoryId > 0 AND cte.CurrentSubcategoryId = 0)
			OR (
				(cte.NewSubcategoryId > 0) 
				AND (cte.NewSubcategoryId <> cte.CurrentSubcategoryId)
			)
		)
END