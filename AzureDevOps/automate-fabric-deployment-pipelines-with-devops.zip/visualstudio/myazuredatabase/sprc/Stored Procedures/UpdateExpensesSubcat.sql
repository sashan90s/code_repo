﻿






-- =============================================
-- Author:      Name
-- Create Date: 
-- Description: 
-- =============================================
CREATE PROCEDURE [sprc].[UpdateExpensesSubcat]
	@ProcessId nvarchar(50)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON

/****** Script for SelectTopNRows command from SSMS  ******/
MERGE 
	[dim].[ExpensesSubcat] AS tgt  
USING 
	(SELECT * FROM [stg].[ExpensesSubcat] WHERE [ProcessId] = @ProcessId) as src  
ON 
	tgt.[Id] = src.[Id]
WHEN MATCHED AND tgt.[Description] <> src.[Description] or tgt.[Retailers] <> src.[Retailers] THEN 
	UPDATE SET [Description] = src.[Description], [Retailers] = src.[Retailers], [UpsertDtTm] = getdate()  
;

EXEC [sprc].[CategorizeExpenses]; 

END
