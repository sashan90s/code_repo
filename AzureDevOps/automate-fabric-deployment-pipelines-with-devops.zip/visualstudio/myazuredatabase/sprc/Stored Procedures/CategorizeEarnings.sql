﻿










-- =============================================
-- Author:      Name
-- Create Date: 
-- Description: 
-- =============================================
CREATE PROCEDURE [sprc].[CategorizeEarnings]
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON

/****** Script for SelectTopNRows command from SSMS  ******/

	UPDATE [stg].[Deposits]  SET [RT]=1 WHERE [Description] LIKE '%Reservert transaksjon%'

	DECLARE @SurrogateKey INT,@Date DATE,@Deposits DECIMAL(16,2),@AccountId NVARCHAR(50)
	DECLARE ReservedTransactions CURSOR FOR 
		SELECT
			[SurrogateKey],[Date],[Deposits],[AccountId]
		FROM 
			[fact].[Deposits]
		WHERE 
			[RT]=1  
	OPEN ReservedTransactions
	FETCH NEXT FROM ReservedTransactions INTO @SurrogateKey,@Date,@Deposits,@AccountId
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		UPDATE A SET A.[DepositId] = @SurrogateKey
		FROM [stg].[Deposits] A
		INNER JOIN (
			SELECT
				[SurrogateKey]
				,ROW_NUMBER() OVER (PARTITION BY [Date],[Deposits],[AccountId] ORDER BY [SurrogateKey]) as Dedup
			FROM 
				[stg].[Deposits]
			WHERE 1 = 1 
				AND [Date]=@Date 
				AND [Deposits]=@Deposits
				AND [AccountId]=@AccountId
				AND [DepositId] IS NULL 
				AND ISNULL([RT],0)=0
		) B on A.[SurrogateKey]=B.[SurrogateKey] and B.[Dedup] = 1 
		FETCH NEXT FROM ReservedTransactions INTO @SurrogateKey,@Date,@Deposits,@AccountId
	END 
	CLOSE ReservedTransactions;  
	DEALLOCATE ReservedTransactions; 

	UPDATE A SET 
		A.[Description] = B.[Description], A.[Interest_date] = B.[Interest_date], A.[RT] = B.[RT]
	FROM 
		[fact].[Deposits] A 
	INNER JOIN 
		[stg].[Deposits] B ON A.[SurrogateKey] = B.[DepositId]

	INSERT INTO [fact].[Deposits]
		([Date], [Description], [Interest_date], [Deposits], [SubcategoryId], [UpsertDtTm], [Tag], [InputFileName], [AccountId], [RT])
	SELECT 
		[Date], [Description], [Interest_date], [Deposits], [SubcategoryId], [UpsertDtTm], [Tag], [InputFileName], [AccountId], [RT]
	FROM 
		[stg].[Deposits] A
	WHERE 1 = 1
		AND A.[DepositId] IS NULL 

	TRUNCATE TABLE [stg].[Deposits]; 

	;WITH cte AS (
		SELECT 
			ISNULL(esc.[Id],0) as NewSubcategoryId,
			--esc.[Description] as NewSubcategoryDesc,
			--esc.[Customers],
			ROW_NUMBER() OVER (PARTITION BY w.[SurrogateKey] ORDER BY esc.[Id]) as Dedup,
			w.[SurrogateKey],
			w.[SubcategoryId] as CurrentSubcategoryId
		FROM 
			[fact].[Deposits] AS w 
		LEFT JOIN 
			(
				SELECT 
					[Id],[Description],TRIM(value) [Customers]
				FROM 
					[dim].[EarningsSubcat]
				CROSS APPLY 
					STRING_SPLIT (Customers,';') 
			) AS esc ON CHARINDEX([Customers], w.[Description]) > 0
		WHERE 1 = 1 
			AND IsNull(w.Locked,0)=0
	)

	--SELECT w.*
	UPDATE w SET w.[SubcategoryId] = cte.NewSubcategoryId 
	FROM 
		[fact].[Deposits] w 
		INNER JOIN cte ON w.SurrogateKey = cte.SurrogateKey
	WHERE 1 = 1 
		AND Dedup = 1 
		AND (
			(cte.NewSubcategoryId > 0 AND cte.CurrentSubcategoryId = 0)
			OR (
				(cte.NewSubcategoryId > 0) 
				AND (cte.NewSubcategoryId <> cte.CurrentSubcategoryId)
			)
		)
END