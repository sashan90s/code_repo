﻿







-- =============================================
-- Author:      Name
-- Create Date: 
-- Description: 
-- =============================================
CREATE PROCEDURE [sprc].[UpdateEarningsSubcat]
	@ProcessId nvarchar(50)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON

/****** Script for SelectTopNRows command from SSMS  ******/
MERGE 
	[dim].[EarningsSubcat] AS tgt  
USING 
	(SELECT * FROM [stg].[EarningsSubcat] WHERE [ProcessId] = @ProcessId) as src  
ON 
	tgt.[Id] = src.[Id]
WHEN MATCHED AND tgt.[Description] <> src.[Description] or tgt.[Customers] <> src.[Customers] THEN 
	UPDATE SET [Description] = src.[Description], [Customers] = src.[Customers], [UpsertDtTm] = getdate()  
;

EXEC [sprc].[CategorizeEarnings]; 

END
