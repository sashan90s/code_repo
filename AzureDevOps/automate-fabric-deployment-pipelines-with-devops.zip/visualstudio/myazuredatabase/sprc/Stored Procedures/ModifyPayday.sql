﻿









-- =============================================
-- Author:      Name
-- Create Date: 
-- Description: 
-- =============================================
CREATE PROCEDURE [sprc].[ModifyPayday]
  @CurrentPayDay AS DATE = '2023-06-23'
  ,@Interval AS INT = -1
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON

/****** Script for SelectTopNRows command from SSMS  ******/

  IF @Interval<0
  BEGIN  
	  --SELECT A.[Date],A.[BudgetYYYYMM],B.[Date],B.[BudgetYYYYMM]
	  UPDATE A SET A.[BudgetYYYYMM] = B.[BudgetYYYYMM]
	  FROM 
		[dim].[Dates]  A 
	  OUTER APPLY (
		SELECT [Date],[BudgetYYYYMM],[IsPaydayNO] FROM [dim].[Dates] WHERE [Date] = @CurrentPayDay AND [IsPaydayNO]=1
	  ) B 
	  WHERE 
		A.[Date] >= DATEADD (Day,@Interval,@CurrentPayDay) AND A.[Date] < @CurrentPayDay

	  --SELECT A.[Date],A.[IsPaydayNO],1
	  UPDATE A SET A.[IsPaydayNO] = 1
	  FROM 
		[dim].[Dates]  A 
	  WHERE 
		A.[Date] = DATEADD (Day,@Interval,@CurrentPayDay) 

	  --SELECT A.[Date],A.[IsPaydayNO],0 
	  UPDATE A SET A.[IsPaydayNO] = 0
	  FROM 
		[dim].[Dates]  A 
	  WHERE 
		A.[Date] = @CurrentPayDay
  END 
 
END
