﻿




-- =============================================
-- Author:      Name
-- Create Date: 
-- Description: 
-- =============================================
CREATE PROCEDURE [sprc].[UpdateBudget]
	@ProcessId nvarchar(50)
	,@AccountId nvarchar(50)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON

/****** Script for SelectTopNRows command from SSMS  ******/
;WITH tgt as (
	SELECT 
		[SurrogateKey], [AccountBudgetYYYYMM], [BudgetYYYYMM], [AccountId], [SubcategoryId], [Amount], [UpsertDtTm]
	FROM 
		[fact].[Budget]  
	WHERE [AccountId]=@AccountId
),
src AS (
	SELECT
		([AccountId]+'-'+CAST([BudgetYYYYMM] AS NCHAR(6))+'-'+ CAST([SubcategoryId] AS NVARCHAR(3))) AS [SurrogateKey]
		,([AccountId]+'-'+CAST([BudgetYYYYMM] AS NCHAR(6))) AS [AccountBudgetYYYYMM]
		,[BudgetYYYYMM]
		,[AccountId]
		,[SubcategoryId]
		,[Amount]
		,ROW_NUMBER() OVER (PARTITION BY [AccountId],[BudgetYYYYMM],[SubcategoryId] ORDER BY [RowNumber] ASC) as Dedup
	FROM 
		[stg].[Budget] 
	WHERE 1 = 1 
		AND [ProcessId] = @ProcessId
		AND [AccountId] = @AccountId
) 

MERGE 
	tgt 
USING 
	(SELECT * FROM src WHERE Dedup = 1) as src  
ON 
	tgt.[SurrogateKey] = src.[SurrogateKey]
WHEN MATCHED AND tgt.[Amount] <> src.[Amount] THEN 
	UPDATE SET [Amount] = src.[Amount], [UpsertDtTm] = getdate()  
WHEN NOT MATCHED BY TARGET THEN 
    INSERT ([SurrogateKey], [AccountBudgetYYYYMM], [BudgetYYYYMM], [AccountId], [SubcategoryId], [Amount])  
    VALUES (src.[SurrogateKey], src.[AccountBudgetYYYYMM], src.[BudgetYYYYMM], src.[AccountId], src.[SubcategoryId], src.[Amount])  	
WHEN NOT MATCHED BY SOURCE THEN 
	DELETE
;

END