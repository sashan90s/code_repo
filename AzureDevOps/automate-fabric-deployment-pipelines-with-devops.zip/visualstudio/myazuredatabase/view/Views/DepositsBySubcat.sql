﻿








CREATE VIEW [view].[DepositsBySubcat] AS

	SELECT
		CAST(fd.[AccountId]+'-'+CAST(fd.[BudgetYYYYMM] AS NCHAR(6)) + '-' +CAST(fd.[SubcategoryId] AS NVARCHAR(3)) AS NVARCHAR(60)) as [SurrogateKey],
		CAST(fd.[AccountId]+'-'+CAST(fd.[BudgetYYYYMM] AS NCHAR(6)) AS NVARCHAR(60)) as [AccountBudgetYYYYMM],
		fd.[BudgetYYYYMM],
		fd.[AccountId],
		fd.[SubcategoryId],
		SUM(fd.[Deposits]) AS Amount
	FROM 
		[view].[Deposits] fd
	GROUP BY
		fd.[BudgetYYYYMM],
		fd.[AccountId],
		fd.[SubcategoryId]