﻿




















CREATE VIEW [view].[Withdrawals] AS

WITH CTE AS (
	SELECT 
		NULL AS [SurrogateKey],
		NULL AS [AccountId],
		NULL AS [Date], 
		NULL AS [Description], 
		NULL AS [Withdrawals],
		0 AS [SubcategoryId],
		NULL AS [Subcategory],
		NULL AS [CategoryId],
		NULL AS [Category],
		NULL AS [TransactionType],
		0 AS [BudgetSubcategoryId],
		NULL AS [BudgetSubcategory],
		NULL AS [BudgetYYYYMM],
		NULL AS [Tag]
)

SELECT * FROM CTE 
UNION ALL
SELECT --TOP 10000 
	A.[SurrogateKey],
	A.[AccountId],
	A.[Interest_date] AS [Date], 
	A.[Description], 
	ROUND(A.[Withdrawals],0) AS [Withdrawals],
	B.[Id] AS SubcategoryId,
	B.[Description] AS Subcategory,
	C.[Id] AS CategoryId,
	C.[Description] AS Category,
	D.[Description] AS TransactionType,
	F.[Id] AS BudgetSubcategoryId,
	F.[Description] AS BudgetSubcategory,
	DT.[BudgetYYYYMM],
	A.[Tag]
FROM 
	[fact].[Withdrawals] A 
	LEFT JOIN [dim].[Dates] DT ON A.[Interest_date] = DT.[Date]
	LEFT JOIN [dim].[ExpensesSubcat] B ON A.SubcategoryId = B.Id
	LEFT JOIN [dim].[ExpensesCat] C ON B.CategoryId = C.Id
	LEFT JOIN [dim].[TransactionType] D ON C.ExpenseTypeId = D.Id
	OUTER APPLY (
		SELECT COUNT(1) AS CntTransactions FROM [fact].[Deposits] WHERE [WithdrawalId] = A.[SurrogateKey]
	) E
	LEFT JOIN [dim].[ExpensesSubcat] F ON ISNULL(A.BudgetSubcategoryId,A.SubcategoryId) = F.Id
WHERE 1 = 1
	AND ISNULL(A.[Hidden],0)=0
	AND A.[DepositId] IS NULL
	AND E.[CntTransactions] = 0
--ORDER BY
--	DT.[BudgetYYYYMM] DESC
