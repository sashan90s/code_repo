﻿










CREATE VIEW [view].[WithdrawalsBySubcat] AS

WITH cte AS (
	SELECT
		CAST(fw.[AccountId]+'-'+CAST(fw.[BudgetYYYYMM] AS NCHAR(6))+'-'+CAST(fw.[BudgetSubcategoryId] AS NVARCHAR(3)) AS NVARCHAR(60)) as [SurrogateKey],
		CAST(fw.[AccountId]+'-'+CAST(fw.[BudgetYYYYMM] AS NCHAR(6)) AS NVARCHAR(60)) as [AccountBudgetYYYYMM],
		fw.[BudgetYYYYMM],
		fw.[AccountId],
		fw.[BudgetSubcategoryId],
		SUM(fw.[Withdrawals]) AS Amount
	FROM 
		[view].[Withdrawals] fw
	GROUP BY
		fw.[BudgetYYYYMM],
		fw.[AccountId],
		fw.[BudgetSubcategoryId]
)

SELECT 
	COALESCE(cte.[AccountId],b.[AccountId]) AS [AccountId],
	COALESCE(cte.[AccountBudgetYYYYMM],b.[AccountBudgetYYYYMM]) AS [AccountBudgetYYYYMM],
	COALESCE(cte.[BudgetYYYYMM],b.[BudgetYYYYMM]) AS [BudgetYYYYMM],
	COALESCE(cte.[BudgetSubcategoryId],b.[SubcategoryId]) AS [SubcategoryId],
	ISNULL(cte.Amount,0) AS ExpensesAmount,
	ISNULL(b.Amount,0) AS BudgetAmount
FROM 
	cte 
	FULL JOIN [fact].[Budget] b ON cte.[SurrogateKey] = b.[SurrogateKey]
WHERE 1 = 1 
	AND (
		ISNULL(cte.Amount,0) > 0
		OR ISNULL(b.Amount,0) > 0  
	)
