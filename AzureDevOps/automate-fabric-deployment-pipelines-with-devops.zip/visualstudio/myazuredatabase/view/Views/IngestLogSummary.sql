﻿

















CREATE VIEW [view].[IngestLogSummary] AS
SELECT TOP 10000 
	[AccountId]
	,count(1) as CountProcess
	,max([UpsertDtTm]) as LastProcess
FROM 
	[stg].[IngestLog] A 
WHERE 
	[Completed] = 1 
GROUP BY
	[AccountId]

