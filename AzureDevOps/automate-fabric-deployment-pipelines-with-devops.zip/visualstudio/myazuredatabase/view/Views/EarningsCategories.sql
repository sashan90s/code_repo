﻿
















CREATE VIEW [view].[EarningsCategories] AS
SELECT TOP 10000 
	B.[Id] AS SubcategoryId
	,B.[Description] AS SubcategoryDesc
	,A.[Description] AS CategoryDesc
	,C.[Description] AS TransactionType
	,B.[Customers] AS Customers
	,D.[OperationCnt]
FROM 
	[dim].[EarningsCat] A 
	INNER JOIN [dim].[EarningsSubcat] B ON A.[Id] = B.[CategoryId]
	INNER JOIN [dim].[TransactionType] C ON A.[EarningTypeId] = C.[Id]
	OUTER APPLY (
		SELECT 
			COUNT(1) AS [OperationCnt]
		FROM 
			[fact].[Deposits]
		WHERE
			[SubcategoryId] = B.[Id]
	) D
ORDER BY 
	A.[Id] ASC, B.[Description] ASC  

