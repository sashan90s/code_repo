﻿





















CREATE VIEW [view].[Deposits] AS

WITH CTE AS (
	SELECT 
		NULL AS [SurrogateKey],
		NULL AS [AccountId],
		NULL AS [Date], 
		NULL AS [Description], 
		NULL AS [Deposits],
		0 AS [SubcategoryId],
		NULL AS [Subcategory],
		NULL AS [CategoryId],
		NULL AS [Category],
		NULL AS [TransactionType],
		NULL AS [BudgetYYYYMM],
		NULL AS [Tag]
)

SELECT * FROM CTE 
UNION ALL
SELECT --TOP 10000 
	A.[SurrogateKey],
	A.[AccountId],
	A.[Interest_date] AS [Date], 
	A.[Description], 
	ROUND(A.[Deposits],0) AS [Deposits],
	B.[Id] AS [SubcategoryId],
	B.[Description] AS [Subcategory],
	C.[Id] AS [CategoryId],
	C.[Description] AS [Category],
	D.[Description] AS [TransactionType],
	DT.[BudgetYYYYMM],
	A.[Tag]
FROM 
	[fact].[Deposits] A 
	LEFT JOIN [dim].[Dates] DT ON A.[Interest_date] = DT.[Date]
	LEFT JOIN [dim].[EarningsSubcat] B ON A.SubcategoryId = B.Id
	LEFT JOIN [dim].[EarningsCat] C ON B.CategoryId = C.Id
	LEFT JOIN [dim].[TransactionType] D ON C.EarningTypeId = D.Id
	OUTER APPLY (
		SELECT COUNT(1) AS CntTransactions FROM [fact].[Withdrawals] WHERE [DepositId] = A.[SurrogateKey]
	) E
WHERE 1 = 1 AND 
	ISNULL(A.[Hidden],0)=0
	AND A.[WithdrawalId] IS NULL
	AND E.[CntTransactions] = 0
--ORDER BY
--	DT.[BudgetYYYYMM] DESC
