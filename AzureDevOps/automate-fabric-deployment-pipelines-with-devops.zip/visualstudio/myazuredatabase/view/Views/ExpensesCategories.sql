﻿

















CREATE VIEW [view].[ExpensesCategories] AS
SELECT TOP 10000 
	B.[Id] AS SubcategoryId
	,B.[Description] AS SubcategoryDesc
	,A.[Description] AS CategoryDesc
	,C.[Description] AS TransactionType
	,B.[Retailers]
	,D.OperationCnt
FROM 
	[dim].[ExpensesCat] A 
	INNER JOIN [dim].[ExpensesSubcat] B ON A.[Id] = B.[CategoryId]
	INNER JOIN [dim].[TransactionType] C ON A.[ExpenseTypeId] = C.[Id]
	OUTER APPLY (
		SELECT 
			COUNT(1) AS [OperationCnt]
		FROM 
			[fact].[Withdrawals]
		WHERE
			[SubcategoryId] = B.[Id]
	) D
ORDER BY 
	A.[Id] ASC, B.[Description] ASC  

