﻿CREATE TABLE [stg].[ExpensesSubcat] (
    [ProcessId]   NVARCHAR (50)  NOT NULL,
    [Id]          TINYINT        NOT NULL,
    [Description] NVARCHAR (100) NOT NULL,
    [Retailers]   NVARCHAR (MAX) NOT NULL
);

