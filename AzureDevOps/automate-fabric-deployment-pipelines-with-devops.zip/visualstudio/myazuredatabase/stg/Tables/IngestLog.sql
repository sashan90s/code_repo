﻿CREATE TABLE [stg].[IngestLog] (
    [Id]            SMALLINT       IDENTITY (1, 1) NOT NULL,
    [AccountId]     NVARCHAR (50)  NOT NULL,
    [PipelineRunId] NVARCHAR (255) NOT NULL,
    [Completed]     BIT            CONSTRAINT [DF_IngestLog_Completed] DEFAULT ((0)) NOT NULL,
    [UpsertDtTm]    DATETIME       CONSTRAINT [DF_IngestLog_UpsertDtTm] DEFAULT (getdate()) NOT NULL,
    CONSTRAINT [PK_IngestLog] PRIMARY KEY CLUSTERED ([Id] ASC)
);

