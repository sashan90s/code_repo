﻿CREATE TABLE [stg].[Budget] (
    [ProcessId]     NVARCHAR (50)   NULL,
    [BudgetYYYYMM]  INT             NULL,
    [AccountId]     NVARCHAR (50)   NULL,
    [SubcategoryId] TINYINT         NULL,
    [Amount]        DECIMAL (16, 2) NULL,
    [RowNumber]     SMALLINT        NULL
);

