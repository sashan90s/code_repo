﻿CREATE TABLE [stg].[EarningsSubcat] (
    [ProcessId]   NVARCHAR (50)  NOT NULL,
    [Id]          TINYINT        NOT NULL,
    [Description] NVARCHAR (100) NOT NULL,
    [Customers]   NVARCHAR (MAX) NOT NULL
);

