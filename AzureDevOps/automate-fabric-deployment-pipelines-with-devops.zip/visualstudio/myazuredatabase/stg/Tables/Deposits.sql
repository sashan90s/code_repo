﻿CREATE TABLE [stg].[Deposits] (
    [SurrogateKey]  INT             IDENTITY (1, 1) NOT NULL,
    [Date]          DATE            NOT NULL,
    [Description]   NVARCHAR (255)  NOT NULL,
    [Interest_date] DATE            NOT NULL,
    [Deposits]      DECIMAL (16, 2) NOT NULL,
    [SubcategoryId] TINYINT         DEFAULT ((0)) NOT NULL,
    [UpsertDtTm]    DATETIME        DEFAULT (getdate()) NOT NULL,
    [Tag]           NVARCHAR (100)  DEFAULT ('') NOT NULL,
    [InputFileName] NVARCHAR (255)  NOT NULL,
    [AccountId]     NVARCHAR (50)   NOT NULL,
    [RT]            BIT             NULL,
    [DepositId]     INT             NULL,
    CONSTRAINT [PK_Deposits] PRIMARY KEY CLUSTERED ([SurrogateKey] ASC)
);

